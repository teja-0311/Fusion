from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    ProjectProposalViewSet, ConsultancyProposalViewSet, ProgressReportViewSet,
    FundRequestViewSet, StaffAppointmentRequestViewSet
)

router = DefaultRouter()
router.register(r'proposals', ProjectProposalViewSet, basename='proposals')
router.register(r'consultancies', ConsultancyProposalViewSet, basename='consultancies')
router.register(r'progress', ProgressReportViewSet, basename='progress')
router.register(r'funds', FundRequestViewSet, basename='funds')
router.register(r'staff-requests', StaffAppointmentRequestViewSet, basename='staff-requests')

urlpatterns = [
    path('', include(router.urls)),
]
