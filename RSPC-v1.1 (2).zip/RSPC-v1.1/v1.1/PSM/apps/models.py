from django.db import models
from django.contrib.auth import get_user_model
from django.utils import timezone

User = get_user_model()

STATUS_CHOICES = [
    ('draft','Draft'),
    ('submitted','Submitted'),
    ('vetted','Vetted by HoD'),
    ('verified','Verified by Admin'),
    ('approved','Approved'),
    ('rejected','Rejected'),
]

class ProjectProposal(models.Model):
    project_code = models.CharField(max_length=50, unique=True, blank=True, null=True)
    title = models.CharField(max_length=255)
    abstract = models.TextField()
    pi = models.ForeignKey(User, related_name='proposals', on_delete=models.CASCADE)
    department = models.CharField(max_length=120, blank=True, null=True)
    start_date = models.DateField()
    end_date = models.DateField()
    total_budget = models.DecimalField(max_digits=12, decimal_places=2)
    personnel_cost = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    equipment_cost = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    consumables_cost = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    travel_cost = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    overhead_cost = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    status = models.CharField(max_length=30, choices=STATUS_CHOICES, default='draft')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.title} ({self.pi})"

    def calculate_overhead(self, rate=0.10):
        base = self.personnel_cost + self.equipment_cost + self.consumables_cost + self.travel_cost
        self.overhead_cost = base * rate
        self.total_budget = base + self.overhead_cost
        return self.total_budget

class ConsultancyProposal(models.Model):
    title = models.CharField(max_length=255)
    client = models.CharField(max_length=255)
    pi = models.ForeignKey(User, related_name='consultancies', on_delete=models.CASCADE)
    days = models.PositiveIntegerField(default=0)
    daily_rate = models.DecimalField(max_digits=10, decimal_places=2)
    overhead_rate = models.DecimalField(max_digits=4, decimal_places=2, default=0.20)
    total_fee = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    status = models.CharField(max_length=30, choices=STATUS_CHOICES, default='draft')
    created_at = models.DateTimeField(auto_now_add=True)

    def calculate_fee(self, min_daily=2000):
        rate = max(self.daily_rate, min_daily)
        base = rate * self.days
        self.total_fee = base + (base * float(self.overhead_rate))
        return self.total_fee

class ProgressReport(models.Model):
    project = models.ForeignKey(ProjectProposal, related_name='progress_reports', on_delete=models.CASCADE)
    submitted_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    summary = models.TextField()
    budget_utilization = models.TextField(blank=True)
    supporting_documents = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

class FundRequest(models.Model):
    project = models.ForeignKey(ProjectProposal, related_name='fund_requests', on_delete=models.CASCADE)
    requested_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    budget_head = models.CharField(max_length=120)
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    supporting_documents = models.BooleanField(default=False)
    status = models.CharField(max_length=30, choices=STATUS_CHOICES, default='draft')
    created_at = models.DateTimeField(auto_now_add=True)

class StaffAppointmentRequest(models.Model):
    project = models.ForeignKey(ProjectProposal, related_name='staff_requests', on_delete=models.CASCADE)
    role = models.CharField(max_length=120)
    duration_months = models.PositiveIntegerField()
    monthly_stipend = models.DecimalField(max_digits=10, decimal_places=2)
    requested_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    status = models.CharField(max_length=30, choices=STATUS_CHOICES, default='draft')
    created_at = models.DateTimeField(auto_now_add=True)
