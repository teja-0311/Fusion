from decimal import Decimal
from datetime import date

def validate_duration(start_date, end_date):
    if not start_date or not end_date:
        return False, 'Start and end dates are required.'
    months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
    if months < 6 or months > 60:
        return False, 'Project duration must be between 6 months and 5 years. (BR-RSPC-003)'
    return True, None

def calculate_overhead(personnel, equipment, consumables, travel, rate=Decimal('0.10')):
    base = Decimal(personnel) + Decimal(equipment) + Decimal(consumables) + Decimal(travel)
    overhead = (base * rate).quantize(Decimal('0.01'))
    total = (base + overhead).quantize(Decimal('0.01'))
    return overhead, total

def personnel_percentage_ok(personnel_cost, total_budget, max_percentage=Decimal('60')):
    if total_budget == 0:
        return False, 'Total budget must be > 0'
    perc = (Decimal(personnel_cost) / Decimal(total_budget)) * 100
    if perc > max_percentage:
        return False, f'Personnel costs exceed {max_percentage}% of total budget. (BR-RSPC-005)'
    return True, None

def file_upload_allowed(filename, size_mb):
    allowed = ['.pdf','.doc','.docx','.xls','.xlsx','.jpg','.jpeg','.png']
    max_mb = 25
    ext = filename.lower().rsplit('.',1)[-1] if '.' in filename else ''
    if ('.' + ext) not in allowed:
        return False, 'File format not allowed. (BR-RSPC-016)'
    if size_mb > max_mb:
        return False, f'File exceeds maximum allowed size of {max_mb}MB.'
    return True, None
