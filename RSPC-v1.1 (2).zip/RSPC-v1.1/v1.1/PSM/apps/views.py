from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import ProjectProposal, ConsultancyProposal, ProgressReport, FundRequest, StaffAppointmentRequest
from .serializers import (
    ProjectProposalSerializer, ConsultancyProposalSerializer,
    ProgressReportSerializer, FundRequestSerializer, StaffAppointmentRequestSerializer
)
from . import services
from django.shortcuts import get_object_or_404

class ProjectProposalViewSet(viewsets.ModelViewSet):
    queryset = ProjectProposal.objects.all()
    serializer_class = ProjectProposalSerializer

    def perform_create(self, serializer):
        proposal = serializer.save()
        # auto-calc overhead on create
        proposal.calculate_overhead()
        proposal.save()

    @action(detail=True, methods=['post'])
    def submit(self, request, pk=None):
        proposal = self.get_object()
        try:
            updated = services.submit_project_proposal(proposal)
        except Exception as e:
            return Response({'detail': str(e)}, status=status.HTTP_400_BAD_REQUEST)
        serializer = self.get_serializer(updated)
        return Response(serializer.data, status=status.HTTP_200_OK)

class ConsultancyProposalViewSet(viewsets.ModelViewSet):
    queryset = ConsultancyProposal.objects.all()
    serializer_class = ConsultancyProposalSerializer

    @action(detail=True, methods=['post'])
    def calc_fee(self, request, pk=None):
        obj = self.get_object()
        fee = services.calculate_consultancy_fee(obj)
        return Response({'total_fee': fee})

class ProgressReportViewSet(viewsets.ModelViewSet):
    queryset = ProgressReport.objects.all()
    serializer_class = ProgressReportSerializer

class FundRequestViewSet(viewsets.ModelViewSet):
    queryset = FundRequest.objects.all()
    serializer_class = FundRequestSerializer

    @action(detail=True, methods=['post'])
    def verify(self, request, pk=None):
        fr = self.get_object()
        project = get_object_or_404(ProjectProposal, pk=fr.project_id)
        try:
            services.verify_fund_request(fr, project)
        except Exception as e:
            return Response({'detail': str(e)}, status=status.HTTP_400_BAD_REQUEST)
        return Response({'status': 'verified'})

class StaffAppointmentRequestViewSet(viewsets.ModelViewSet):
    queryset = StaffAppointmentRequest.objects.all()
    serializer_class = StaffAppointmentRequestSerializer

    @action(detail=True, methods=['post'])
    def submit_request(self, request, pk=None):
        sr = self.get_object()
        project = get_object_or_404(ProjectProposal, pk=sr.project_id)
        try:
            services.submit_staff_request(sr, project)
        except Exception as e:
            return Response({'detail': str(e)}, status=status.HTTP_400_BAD_REQUEST)
        return Response({'status': 'submitted'})
