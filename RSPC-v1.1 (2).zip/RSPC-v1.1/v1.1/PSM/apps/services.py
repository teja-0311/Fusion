from django.utils.crypto import get_random_string
from .models import ProjectProposal, ConsultancyProposal, FundRequest, StaffAppointmentRequest
from . import policy
from decimal import Decimal

def generate_project_code(prefix='RSPC'):
    return f"{prefix}-{get_random_string(8).upper()}"

def submit_project_proposal(proposal: ProjectProposal):
    # calculate overhead and total budget
    proposal.calculate_overhead()
    # enforce personnel percentage rule
    ok, msg = policy.personnel_percentage_ok(proposal.personnel_cost, proposal.total_budget)
    if not ok:
        raise ValueError(msg)
    # assign project code and mark as submitted
    if not proposal.project_code:
        proposal.project_code = generate_project_code()
    proposal.status = 'submitted'
    proposal.save()
    return proposal

def calculate_consultancy_fee(obj: ConsultancyProposal):
    return obj.calculate_fee()

def verify_fund_request(fund_request: FundRequest, project: ProjectProposal):
    # BR-RSPC-010: amount must be within available balance (simple example)
    # Here we assume project's total_budget is the sanctioned amount and sum of existing requests is out of scope.
    if Decimal(fund_request.amount) > Decimal(project.total_budget):
        raise ValueError('Requested amount exceeds project sanctioned total. (BR-RSPC-010)')
    if not fund_request.supporting_documents:
        raise ValueError('Supporting documents are required for fund requests. (BR-RSPC-010)')
    fund_request.status = 'submitted'
    fund_request.save()
    return fund_request

def submit_staff_request(staff_request: StaffAppointmentRequest, project: ProjectProposal):
    # BR-RSPC-008: check if budget can accommodate the staff cost (simplified)
    total_staff_cost = Decimal(staff_request.duration_months) * Decimal(staff_request.monthly_stipend)
    available = Decimal(project.personnel_cost)
    if total_staff_cost > available:
        raise ValueError('Staff cost exceeds available personnel budget for the project. (BR-RSPC-008)')
    staff_request.status = 'submitted'
    staff_request.save()
    return staff_request
