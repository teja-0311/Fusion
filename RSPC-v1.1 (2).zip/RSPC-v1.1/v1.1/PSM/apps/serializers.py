from rest_framework import serializers
from .models import ProjectProposal, ConsultancyProposal, ProgressReport, FundRequest, StaffAppointmentRequest

class ProjectProposalSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProjectProposal
        fields = '__all__'
        read_only_fields = ('project_code','created_at','updated_at','status')

    def validate(self, data):
        # duration validation (BR-RSPC-003)
        start = data.get('start_date', None) or self.instance.start_date
        end = data.get('end_date', None) or self.instance.end_date
        if start and end:
            duration_months = (end.year - start.year) * 12 + (end.month - start.month)
            if duration_months < 6 or duration_months > 60:
                raise serializers.ValidationError('Project duration must be between 6 months and 5 years (BR-RSPC-003).')
        # budget validation will be performed in service layer
        return data

class ConsultancyProposalSerializer(serializers.ModelSerializer):
    class Meta:
        model = ConsultancyProposal
        fields = '__all__'
        read_only_fields = ('total_fee','created_at','status')

class ProgressReportSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProgressReport
        fields = '__all__'
        read_only_fields = ('created_at',)

class FundRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = FundRequest
        fields = '__all__'
        read_only_fields = ('status','created_at',)

class StaffAppointmentRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = StaffAppointmentRequest
        fields = '__all__'
        read_only_fields = ('status','created_at',)
