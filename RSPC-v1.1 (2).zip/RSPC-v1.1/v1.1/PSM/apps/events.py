from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import ProjectProposal, ProgressReport, FundRequest, StaffAppointmentRequest

@receiver(post_save, sender=ProjectProposal)
def on_project_proposal_saved(sender, instance, created, **kwargs):
    if created and instance.status == 'submitted':
        # Placeholder: integrate with real notification/email system
        print(f"[RSPC EVENT] New proposal submitted: {instance} -> Notify HoD of {instance.department}")


@receiver(post_save, sender=ProgressReport)
def on_progress_report(sender, instance, created, **kwargs):
    if created:
        print(f"[RSPC EVENT] New progress report submitted for project {instance.project.id} by {instance.submitted_by}")


@receiver(post_save, sender=FundRequest)
def on_fund_request(sender, instance, created, **kwargs):
    if created and instance.status == 'submitted':
        print(f"[RSPC EVENT] Fund request submitted for project {instance.project.id} amount={instance.amount}")


@receiver(post_save, sender=StaffAppointmentRequest)
def on_staff_request(sender, instance, created, **kwargs):
    if created and instance.status == 'submitted':
        print(f"[RSPC EVENT] Staff appointment requested for project {instance.project.id} role={instance.role}")    
